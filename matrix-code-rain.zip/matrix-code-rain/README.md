# Matrix code rain

A Pen created on CodePen.io. Original URL: [https://codepen.io/neilcarpenter/pen/DJopeR](https://codepen.io/neilcarpenter/pen/DJopeR).

Does what you would expect, demo write up here: http://neilcarpenter.com/labs/matrix-rain/